<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{contentbox}prestashop>contentbox_13a0a9f1ae2ecb3c99843a4b507462f0'] = 'Place your content everywhere!';
$_MODULE['<{contentbox}prestashop>contentbox_e0f7ad2ceb27e4c750602bd4dc2c682d'] = 'Your text file is empty.';
$_MODULE['<{contentbox}prestashop>contentbox_f1e2209f12e0d495f3b4a232c96a7b2d'] = 'Module\'s Content';
$_MODULE['<{contentbox}prestashop>contentbox_825057b09450ea429fa3dc530b1b2d7d'] = 'Module\'s Images';
$_MODULE['<{contentbox}prestashop>contentbox_77d2a4ead423f5e1725499c4ba262bc9'] = 'Image Upload';
$_MODULE['<{contentbox}prestashop>contentbox_f9b33ed932eb8c5dc2d260a0c0ba431d'] = 'Update ( Save )';
$_MODULE['<{contentbox}prestashop>contentbox_1b543107f0b4e4a817514f5fc77afac0'] = 'Do you really want to delete this file?';
